# Whiteboard

See the photo. No trailing newline